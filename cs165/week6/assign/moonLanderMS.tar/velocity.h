/********************************************************************
 * File: lander.h
 * Purpose: Holds the definition of the Date class.
 ********************************************************************/

#ifndef VELOCITY_H
#define VELOCITY_H
using namespace std;

class Velocity
{
   private:
      float x;
      float y;
   public:
      Velocity()
      {
      }
      Velocity(float x, float y);
      float getDx();
      float getDy();
      void setDx(float x);
      void setDy(float y);
};
#endif