/********************************************************************
 * File: lander.h
 * Purpose: Holds the definition of the Date class.
 ********************************************************************/

#ifndef LANDER_H
#define LANDER_H
#include "velocity.h"
#include "point.h"
#include "uiDraw.h"
#include "uiInteract.h"
class Lander
{
   private:
      
      bool landed;
      bool alive;
      int fuel;
      float gravity;
   public:
   Point point;
   Velocity velocity;
   Lander()
   {
      point = getPoint();
      velocity = getVelocity();
      
   }
   Velocity getVelocity() const;
   Point getPoint() const; 
   bool isAlive();
   bool isLanded();
   int getFuel();
   bool canThrust();
   void setLanded (bool landed);
   bool setAlive(bool alive);
   void setFuel(int fuel);
   void applyGravity(float gravity);
   void applyThrustLeft();
   void applyThrustRight();
   void applyThrustBottom();
   void advance();
   void draw(); 
};
#endif