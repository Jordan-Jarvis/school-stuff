

#include "velocity.h"

#include <iostream>

using namespace std;
float Velocity:: getDx()
{
   
}

float Velocity::getDy()
{
        
}
void Velocity::setDx(float x)
{
     
}
void Velocity::setDy(float y)
{
     
}