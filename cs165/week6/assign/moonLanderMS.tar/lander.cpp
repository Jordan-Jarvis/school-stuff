/********************************************************************
 * File: lander.cpp
 * Purpose: Holds the implementation of the Date class methods.
 ********************************************************************/
using namespace std;
#include "lander.h"
#include "point.h"
#include "velocity.h"
#include <iostream>


   Velocity Lander::getVelocity() const
   {
      Velocity velocity;
      velocity = this->velocity;
      return velocity;
   }
   Point Lander::getPoint() const
   {
      Point point;
      point = this->point; 
      return point;
   }
   bool Lander::isAlive()
   {
   }
   bool Lander::isLanded() 
   {
   }
   int Lander::getFuel()
   {
      
   }
   bool Lander::canThrust()
   {
   }
   void Lander::setLanded (bool landed)
   {
   }
   bool Lander::setAlive(bool alive)
   {
   }
   void Lander::setFuel(int fuel)
   {
   }
   void Lander::applyGravity(float gravity)
   {
   }
   void Lander::applyThrustLeft()
   {
   }
   void Lander::applyThrustRight()
   {
   }
   void Lander::applyThrustBottom()
   {
   }
   void Lander::advance()
   {
   }
   void Lander::draw()
   {
      drawLander(point);
   }